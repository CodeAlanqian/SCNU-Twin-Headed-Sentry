#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/camera_info.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <visualization_msgs/msg/marker_array.hpp>
#include <image_transport/image_transport.hpp>
#include <image_transport/publisher.hpp>
#include <image_transport/subscriber_filter.hpp>
#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/exact_time.h>
#include "auto_aim_interfaces/msg/armors.hpp"


rclcpp::Node::SharedPtr g_node = nullptr;


class CompareArmors : public rclcpp::Node{
    public:
    CompareArmors():Node("CompareArmors"){
        // define quality of service: all messages that you want to receive must have the same
        custom_qos_profile = rmw_qos_profile_default;
        custom_qos_profile.depth = 5;
        custom_qos_profile.reliability = rmw_qos_reliability_policy_t::RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT;
        custom_qos_profile.history = rmw_qos_history_policy_t::RMW_QOS_POLICY_HISTORY_KEEP_LAST;
        custom_qos_profile.durability = rmw_qos_durability_policy_t::RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL;

        armors_sub_first.subscribe(this, "/detector/armors_first", custom_qos_profile);
        armors_sub_second.subscribe(this, "/detector/armors_second", custom_qos_profile);

        armors_pub_ = this->create_publisher<auto_aim_interfaces::msg::Armors>(
                    "/detector/armors", rclcpp::SensorDataQoS());

        
        message_filters::Synchronizer<exact_policy> syncExact(exact_policy(10), armors_sub_first, armors_sub_second);

    // register the exact time callback
        syncExact.registerCallback(&CompareArmors::exact_sync_callback,this);
    }
    private:
        
        void exact_sync_callback(const auto_aim_interfaces::msg::Armors::SharedPtr armors_first, const auto_aim_interfaces::msg::Armors::SharedPtr armors_second)
        {
            int count1 = armors_first->armors.size();
            
            if (count1 == 0)
            {   
                armors_msg_.armors.clear();
                armors_msg_.header=armors_second->header;
                armors_msg_.armors=armors_second->armors;
                RCLCPP_INFO(rclcpp::get_logger("armor_detector"), "Publishing armors_second");
                armors_pub_->publish(armors_msg_);
            }
            else
            {
                armors_msg_.armors.clear();
                armors_msg_.header=armors_first->header;
                armors_msg_.armors=armors_first->armors;
                RCLCPP_INFO(rclcpp::get_logger("armor_detector"), "Publishing armors_first");
                armors_pub_->publish(armors_msg_);
            }
        }
        message_filters::Subscriber<auto_aim_interfaces::msg::Armors> armors_sub_first;
        message_filters::Subscriber<auto_aim_interfaces::msg::Armors> armors_sub_second;
        rclcpp::Publisher<auto_aim_interfaces::msg::Armors>::SharedPtr armors_pub_;
        rmw_qos_profile_t custom_qos_profile;
        auto_aim_interfaces::msg::Armors armors_msg_;
        typedef message_filters::sync_policies::ExactTime<auto_aim_interfaces::msg::Armors, auto_aim_interfaces::msg::Armors> exact_policy;
};


int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<CompareArmors>());
    rclcpp::shutdown();
    return 0;
}